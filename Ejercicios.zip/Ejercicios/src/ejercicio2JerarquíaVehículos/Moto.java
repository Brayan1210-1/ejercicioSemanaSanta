package ejercicio2JerarquíaVehículos;

public class Moto extends Vehiculo {
	
	@Override
	public void arrancar() {
		System.out.println(" Moto arrancada ");
	}
}
