package ejercicio2JerarquíaVehículos;

public class Vehiculo {
	
public void arrancar() {
	System.out.println(" Vehículo arrancado ");
}

public static void main(String[] args) {
	
	
	Vehiculo auto = new Auto();
	Vehiculo moto = new Moto();
	Vehiculo vehiculo = new Vehiculo();
	
	moto.arrancar();
	System.out.println("");
    auto.arrancar();
    System.out.println("");
    vehiculo.arrancar();
}
}

