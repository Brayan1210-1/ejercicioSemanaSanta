package ejercicio2JerarquíaVehículos;

public class Auto extends Vehiculo {

	@Override
public void arrancar() {
	System.out.println(" Auto arrancado ");
}
}
