package ejercicio1ClaseProducto;


public class Producto {
	
	//Atributos
private String nombre;
private int precio;

//métodos set y get para nombre
public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

//métodos set y get para precio
public int getPrecio() {
	System.out.println(" El precio es: "+ precio);
	return precio;
}

public void setPrecio(int precio) throws Exception {
	if (precio > 0) {
		 this.precio = precio;
	}else
		throw new Exception(" El precio debe ser mayor a 0 ");
	
}

public static void main(String[] args) throws Exception {
	
Producto producto = new Producto();
producto.setPrecio(3);
producto.getPrecio();
}
}
