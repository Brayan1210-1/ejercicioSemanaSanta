package ejercicio4TraducciónUMLJava;

public class Biblioteca {
private int id;
private String nombre;


  //Constructor
	public Biblioteca(int id, String nombre) {
		this.setId(id);
		this.setNombre(nombre);
	}

	//Array para almacenar libros
	public Libro[] almacenarLibros(Libro libro) {
		
		Libro[] arrayLibros = new Libro[1];
		arrayLibros[0] = libro;
		return arrayLibros;
	}
	
	public void mostrarLibros(){
		

		
	}
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
}
