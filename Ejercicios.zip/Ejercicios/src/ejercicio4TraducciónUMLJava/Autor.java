package ejercicio4TraducciónUMLJava;
import java.util.Scanner;

public class Autor {
private String nombre;

public Autor(String nombree) {
	this.setNombre(nombree);
}

public Libro agregarLibros()  {
	Scanner sc = new Scanner(System.in);
	
	   
	System.out.println(" Ingrese el id del libro");
	int id = sc.nextInt();
	
	System.out.println(" Ingrese el título del libro");
	String titulo = sc.next();
	
	System.out.println(" Ingrese la fecha del libro");
	String fechaPublicacion = sc.next();
	
	System.out.println(" Ingrese el nombre del autor");
	String nombreAutor = sc.next();
	nombreAutor = sc.nextLine();
	
	System.out.println("");

	 Libro libro = new Libro(id, titulo, fechaPublicacion, nombreAutor);
   
	 sc.close();
	return libro;
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

}
