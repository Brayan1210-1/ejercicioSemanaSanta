package ejercicio4TraducciónUMLJava;

public class Libro {

	//Atributos de la clase Libro
private int id;
private String titulo;
private String fechaPublicacion; 
private String nombreAutor;
	
	//Constructor de la clase Libro
	public Libro(int id, String titulo, String fechaPublicacion, String nombreAutor) {
		this.setId(id);
		this.setTitulo(titulo);
		this.setFechaPublicacion(fechaPublicacion);
		this.setNombreAutor(nombreAutor);
	}

	//getter y setter id
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	//getter y setter titulo
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	//getter y setter para la fecha
	public String getFechaPublicacion() {
		return fechaPublicacion;
	}

	public void setFechaPublicacion(String fechaPublicacion) {
		this.fechaPublicacion = fechaPublicacion;
	}

	//getter y setter para el nombre del autor
	public String getNombreAutor() {
		return nombreAutor;
	}

	public void setNombreAutor(String nombreAutor) {
		this.nombreAutor = nombreAutor;
	}
}
