package ejercicio4TraducciónUMLJava;

public class Main {

	public static void main(String[] args) {
	
		//Instanciación de la clase biblioteca e impresión del nombre
		Biblioteca biblio = new Biblioteca(0, "Biblioteca Juanes");
		String nombreBiblio = biblio.getNombre();
		System.out.println(nombreBiblio);
		System.out.println("");
			 
  //Instanciación de la clase autor y el método registrar libros
		Autor obj = new Autor(null);
	Libro libro = obj.agregarLibros();
		
	//Se guarda el libro creado por el autor en el array de la clase biblioteca 
	 Libro[] arrayDeLibros = biblio.almacenarLibros(libro);
	 
	 
	 System.out.println(" Lista de libros: ");
	 System.out.println(arrayDeLibros);
	 biblio.mostrarLibros();
	}

}

